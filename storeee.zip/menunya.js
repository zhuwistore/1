const chalk = require('chalk')
const fs = require('fs')

global.menunya = (pushname, prefix, hituet) =>{
	return `╭─❒ 「 *INFO MENU* 」
│
│○ !owner  
│○ !sc  
│○ !ping  
│○ !donate  
│○ !tqto  
│○ !sewa  
│○ !q  
│○ !jasrun  
│○ !sewa  
│○ !buyprem  
│○ !runtime  
│○ !groupbot  
│○ !developer  
│
╰❒ 

╭─❒ 「  *STORE MENU*  」
│
│○ !list  
│○ !addlist  
│○ !updatelist  
│○ !dellist  
│○ !jeda  
│○ !tambah  
│○ !kurang  
│○ !kali  
│○ !bagi  
│○ !setproses  
│○ !changeproses  
│○ !delsetproses  
│○ !setdone  
│○ !changedone  
│○ !delsetdone  
│○ !proses  
│○ !done  
│○ !setwelcome  
│○ !changewelcome  
│○ !delsetwelcome  
│○ !setleft  
│○ !changeleft  
│○ !delsetleft  
│
╰❒

╭─❒ 「 *GROUP MENU* 」 
│
│○ !antiwame  [on/off]
│○ !antiwame2  [on/off]
│○ !antilink  [on/off]
│○ !antilink2  [on/off]
│○ !welcome  [on/off]
│○ !goodbye  [on/off]
│○ !group open
│○ !group close
│○ !hidetag  
│○ !kick  
│○ !linkgc  
│○ !resetlinkgc  
│○ !delete  
│○ !listonline  
│○ !setnamegc  
│○ !setdesc  
│○ !listsewa  
│○ !add  
│○ !promote  
│○ !demote  
│○ !antilinkall  
│○ !sendlinkgc  
│○ !tagall  
│○ !totag
│○ !mute [on/off]
│○ !nsfw [on/off]
│○ !setppgroup
│
╰❒

╭─❒ 「 *OTHER MENU* 」 
│
│○ !afk
│
╰❒

╭─❒ 「 *STICKER MENU* 」 
│
│○ !sticker  
│○ !toimage  
│○ !pinterest  
│○ !ttp  
│○ !smeme  
│○ !attp  
│○ !emojimix  
│○ !wm  
│○ !qc
│
╰❒

╭─❒ 「 *STALKER MENU* 」 
│
│○ !cekidff
│○ !cekidml
│
╰❒

`
}

/*
JANGAN HAPUS THANKS TO DEKS :V
KALO MAU NARUH NAMA LU TARUH AJA
*/

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})